import mongoose from "mongoose";

const customerSupportSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
    },
    phone: {
      type: String,
      required: true,
    },
    supportType: {
      type: String,
      required: true,
    },
    courseName: {
      type: String,
      default: "",
    },
    projectType: {
      type: String,
      default: "",
    },
    message: {
      type: String,
      default: "",
    },
  },
  { timestamps: true }
);

export default mongoose.model(
  "CustomerSupport",
  customerSupportSchema
);